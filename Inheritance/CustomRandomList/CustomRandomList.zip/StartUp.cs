﻿using System;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RandomList list = new RandomList();
            list.Add("pesho");
            list.Add("pesho1");
            list.Add("pesho2");
        }
    }
}
